package com.vidarbha.caller1.algo;

import java.time.ZonedDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

import org.ta4j.core.BarSeries;
import org.ta4j.core.BaseBarSeriesBuilder;

import com.vidarbha.caller1.dto.Candle;
import com.vidarbha.caller1.dto.ZonedCandle;

public class TimeSeriesCreater {

	DataFetcher dataFetcher =new DataFetcher();
	

	
	public List<Candle>   getNormalCandleFifteenMinTimeSeries(String minute, String dateRange) {

		List<Candle> candleList = dataFetcher.getNormalCandleFifteenMinTimeSeries(minute, dateRange);
	//	List<Candle> candleList = dataFetcher.getNormalCandleFifteenMinTimeSeries("15minute",  "2024-07-20&to=2024-08-23");

		return candleList;
	}

}
