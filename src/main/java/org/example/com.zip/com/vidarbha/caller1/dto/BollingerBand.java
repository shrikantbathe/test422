package com.vidarbha.caller1.dto;

import java.util.ArrayList;
import java.util.List;

public class BollingerBand {
	
	
	
	/**
     * Calculates Bollinger Bands for a given list of Doubles.
     * Uses numStdDev = 2.
     * @param prices List of price values.
     * @param period Number of periods for moving average.
     * @return List of Band objects containing middle, upper, and lower band values.
     */
    public static List<Band> calculateBollingerBands(List<Double> prices, int period) {
        final Double numStdDev = 2.0; // Fixed to 2 as requested
        List<Band> bands = new ArrayList<>();
        if (prices == null || prices.size() < period) {
            return bands;
        }

        for (int i = period - 1; i < prices.size(); i++) {
            Double sum = 0.0;
            for (int j = i - period + 1; j <= i; j++) {
                sum += prices.get(j);
            }
            Double mean = sum / period;

            Double variance = 0.0;
            for (int j = i - period + 1; j <= i; j++) {
                variance += Math.pow(prices.get(j) - mean, 2);
            }
            Double stdDev = Math.sqrt(variance / period);

            Double upper = mean + numStdDev * stdDev;
            Double lower = mean - numStdDev * stdDev;

            bands.add(new Band(mean, upper, lower));
        }
        return bands;
    }
    
}
