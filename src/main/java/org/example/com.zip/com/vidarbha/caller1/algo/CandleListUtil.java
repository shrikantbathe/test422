package com.vidarbha.caller1.algo;

import com.vidarbha.caller1.dto.Candle;

import ch.qos.logback.core.net.SyslogOutputStream;

import java.util.Collections;
import java.util.List;

public class CandleListUtil {

    public static void main(String[] args) {

      //  List<Candle> list = CandleList.getCandleSeries("30minute", "2025-02-01&to=2025-05-19");
        List<Candle> list = CandleList.getCandleSeries("60minute", "2025-01-01&to=2025-05-19");
        
        
        //macd = BLACK LINE
        //emaSignalLine15 = REDLINE
        Collections.reverse(list);
//        for (Candle d : list) {
//        	if (d.getMacd().getEmaSignalLine15()!= null) {
//	            System.out.println(d.getClose() + "<>  : " + d.getTime() + "<>  RED: " + d.getMacd().getEmaSignalLine15() + "<> BLACK : " + 
//	            			d.getMacd().getMacd() + "<>  : " +
//	            		(d.getMacd().getMacd() - d.getMacd().getEmaSignalLine15()));
//        	}
//        }
        
        for (Candle d : list) {
//        	
//        	if (false && d.getBand() != null && d.getBand().getUpper() >= d.getClose() && d.getBand().getUpper() <=  d.getOpen() ) {
//       		 	System.out.println( "<>BBBBBBBBBBB:::  : " + d.getTime() + "<>  RED: " +
//       		 				d.getBand().getLower()+ "<>  RED: " + d.getBand().getUpper())  ;
//       		 	 
//			}
//        	
        	
        	
        	
        	
//        	if (d.getBand() != null && d.getBand().getLower() >= d.getOpen() && d.getBand().getLower() <=  d.getClose() ) {
//       		 System.out.println( "<>BBBBBBBBBBB:::  : " + d.getTime() + "<>  RED: " +
//       	d.getBand().getLower()+ "<>  RED: " + d.getBand().getUpper())  ;
//       		 	 
//			}
       	
        	
//        	  if(d.getBand() != null)
//	            System.out.println(d.getClose() + "<>BBBBBBBBBBB:::  : " + d.getTime() + "<>  RED: " + d.getBand().getLower()+ "<>  RED: " + d.getBand().getUpper())  ;
 
        }
        
        main11(list);
    }
    
    
    
    
    
    public static void main1(List<Candle> list ) {

    	 Collections.reverse(list);
        for (int i=0;i< list.size();i++) {
        	
        	if (i>1) {
        		Candle  candle = list.get(i);
        		Candle  candle1 = list.get(i-1);
        		Candle  candle2 = list.get(i-2);
        		if (candle.getMacd().getEmaSignalLine15() != null && candle1.getMacd().getEmaSignalLine15() != null && 
        				candle2.getMacd().getEmaSignalLine15() != null) {
        			
        		
//        			Double d = (candle.getMacd().getMacd() -  candle.getMacd().getEmaSignalLine15());
//        			Double d1 = (candle1.getMacd().getMacd() - candle1.getMacd().getEmaSignalLine15());
//        			Double d2 = (candle2.getMacd().getMacd() - candle2.getMacd().getEmaSignalLine15());
        		 	
        			Double signalA = candle.getMacd().getMacd();
        			Double signalB = candle1.getMacd().getMacd();
        			Double signalC = candle2.getMacd().getMacd();
        			 
        			Double emaA =candle.getMacd().getEmaSignalLine15();
        			Double emaA1 =candle1.getMacd().getEmaSignalLine15();
        			Double emaA2 =candle2.getMacd().getEmaSignalLine15();
        			
        			if ( (signalA <=signalB && signalB<= signalC) && (signalA< emaA && signalB< emaA1 && signalC< emaA2)) {
        				
        				
        				if  (((signalA -emaA ) <0 && (signalA -emaA )> -12) && 
        						((signalB -emaA ) <0 && (signalB -emaA1 )> -12) && 
        						((signalC -emaA ) <0 && (signalC -emaA2)> -12) )
            						
        						
        						{
        					
        				 
        				
        			
        			 //	if ((d>-5 &&d1>-5 &&d2>-5 )&&  (d< 0 &&d1< 0 &&d2< 0 ) && candle2.getMacd().getEmaSignalLine15()>-5) {
        			 System.out.println(candle.getClose() + "<xx>  : " + candle.getTime() + "<> RED : " + candle.getMacd().getEmaSignalLine15() + "<> "
        			 		+ "BLACK : " + 
        					 candle.getMacd().getMacd() + "<>  : " +
                 		(candle.getMacd().getMacd() - candle.getMacd().getEmaSignalLine15()));
        			 	//}
        			}
        			}
        		}
        	}
        	
        }
       
       
//        for (Candle d : list) {
//        	if (d.getMacd().getEmaSignalLine15()!= null) {
//                System.out.println(d.getClose() + "<>  : " + d.getTime() + "<>  : " + d.getMacd().getEmaSignalLine15() + "<>  : " + 
//                			d.getMacd().getMacd() + "<>  : " +
//                		(d.getMacd().getMacd() - d.getMacd().getEmaSignalLine15()));
//        	}
//        }
    }

    
    public static void main11(List<Candle> list ) {
    	 Collections.reverse(list);
        for (int i = 0; i < list.size(); i++) {
            if (i >= 4) {
            	
                Candle candle1 = list.get(i);
                Candle candle2 = list.get(i + 1);
                Candle candle3 = list.get(i + 2);
                Candle candle4 = list.get(i + 3);
               // Candle candle5 = list.get(i - 4);

                Double signal1 = candle1.getMacd().getMacd();
                Double signal2 = candle2.getMacd().getMacd();
                Double signal3 = candle3.getMacd().getMacd();
                Double signal4 = candle4.getMacd().getMacd();
              //  Double signal5 = candle5.getMacd().getMacd();

                Double ema1 = candle1.getMacd().getEmaSignalLine15();
                Double ema2 = candle2.getMacd().getEmaSignalLine15();
                Double ema3 = candle3.getMacd().getEmaSignalLine15();
                Double ema4 = candle4.getMacd().getEmaSignalLine15();
              //  Double ema5 = candle5.getMacd().getEmaSignalLine15();

              
                
                if(signal1 != null && signal2 != null && signal3 != null) {
                if (signal1 < signal2 && signal2 < signal3) {
                	if (signal3 < 0)
                		  System.out.println(candle1.getTime() +"---");
                }
                }
//                if (signal1 != null && signal2 != null && signal3 != null && signal4 != null && signal5 != null &&
//                        ema1 != null && ema2 != null && ema3 != null && ema4 != null && ema5 != null &&
//                        signal1 < ema1 && signal2 < ema2 && signal3 < ema3 && signal4 < ema4 && signal5 < ema5 &&
//                        signal1 < 0 && signal2 < 0 && signal3 < 0 && signal4 < 0 && signal5 < 0 &&
//                        ema1 < 0 && ema2 < 0 && ema3 < 0 && ema4 < 0 && ema5 < 0) { 
//		    	
//		    	
//		    	 System.out.println(candle1.getTime());
//		    	
//		    }
                
        }
     }

     
    }
}




