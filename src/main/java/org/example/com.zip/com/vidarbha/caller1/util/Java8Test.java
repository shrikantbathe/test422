package com.vidarbha.caller1.util;

import java.util.Optional;

public class Java8Test {

	public static void main(String[] args) throws Exception {

		Outer outer = new Outer();
		String email = null;
		Inner Inner1 = new Inner();
		DeepInner deepInner = new DeepInner();
		deepInner.setName("Sharvil");
		Inner1.setDeepInner(deepInner);
		outer.setInner(Inner1);

		String name = Optional.ofNullable(outer.getInner()).map(Inner::getDeepInner).map(DeepInner::getName)
				.map("Mr."::concat).orElse(getName());

		Optional<String> stringOptional = Optional.ofNullable(email);

		String optionalObject1 = stringOptional.orElseThrow(Exception::new);

		System.out.println(optionalObject1);

		System.out.println("-->" + name);

	}

	private static String getName() {
		return "Mr. Shri";
	}
	
}

class Outer {

	Inner inner;

	public Inner getInner() {
		return inner;
	}

	public void setInner(Inner inner) {
		this.inner = inner;
	}

}

class Inner {

	DeepInner deepInner;

	public DeepInner getDeepInner() {
		return deepInner;
	}

	public void setDeepInner(DeepInner deepInner) {
		this.deepInner = deepInner;
	}

}

class DeepInner {

	String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}