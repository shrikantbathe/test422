package com.vidarbha.caller1.algo;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.stream.Collectors;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.vidarbha.caller1.dto.Candle;

public class CandleList {

	public static List<Candle>  getCandleSeries(String minute, String dateRange) {

		TimeSeriesCreater TimeSeriesCreater1 = new TimeSeriesCreater();

		List<Candle> candleList = TimeSeriesCreater1.getNormalCandleFifteenMinTimeSeries(minute, dateRange);
	//	List<Candle> candleList = TimeSeriesCreater1.getNormalCandleFifteenMinTimeSeries("15minute",  "2024-07-20&to=2024-08-23");
		candleList = candleList.stream()
		.filter(c -> c.getTime().isBefore(LocalDateTime.of(c.getTime().toLocalDate(), LocalTime.of(15, 30))))			
		.collect(Collectors.toList());
		
		//System.out.println("Size of prev20: " + prev20.size());

		if (candleList == null || candleList.size() < 1) return null;
		
		IndicatorUtil.calculate20EMA(candleList);
		IndicatorUtil.calculate50EMA(candleList);
		IndicatorUtil.calculate100EMA(candleList);
		IndicatorUtil.calculate200EMA(candleList);
		
		
		
		IndicatorUtil.calculate20SMAaa(candleList);
		
		
		MACDUtil.calculateMACD(candleList);
		IndicatorUtil.setRsiBearFlag(candleList);

		
	//	saveCandles(candleList);
		
		
		return candleList;
		//MACDLINE = BLACK LINE
		//SIgnalLine = REDLINE
			/*	for(Candle d:candleList ) {

					System.out.println(d.getClose()+"<>  : "+ d.getTime()+"<>  : "+d.getMacd().getEmaSignalLine15()+"<>  : "+ d.getMacd().getMacd()
							+"<>  : "+ (d.getMacd().getMacd() - d.getMacd().getEmaSignalLine15()));

				}*/
	}

	
	static void saveCandles(List<Candle> candleList) {
	        ObjectMapper mapper = new ObjectMapper();
	        mapper.registerModule(new JavaTimeModule());
	        try {
	            File file = new File("C:\\Users\\Admin\\Documents\\jsondata\\candle.json");
	            mapper.writerWithDefaultPrettyPrinter().writeValue(file, candleList);
	            System.out.println("JSON file saved successfully!");
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
		
	}
	
	
	
}
