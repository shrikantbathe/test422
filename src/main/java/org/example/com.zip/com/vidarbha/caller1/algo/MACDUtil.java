package com.vidarbha.caller1.algo;

import java.util.List;
import java.util.ListIterator;
import java.util.stream.Collectors;

import com.vidarbha.caller1.dto.Candle;

public class MACDUtil {
 
	public static void calculateMACD(List<Candle> candleList) {

		calculate3EMA(candleList);
		calculate9EMA(candleList);
		calculateMACDLine(candleList);
		calculate15SignalLineEMA1(candleList);
		
	}	
	
	
	public static void calculate3EMA(List<Candle> candleList) {

		List<Candle> first3ElementsList = candleList.stream().limit(3).collect(Collectors.toList());
		double average = first3ElementsList.stream().map(d -> d.getClose()).mapToDouble(Number::doubleValue).average().getAsDouble();
		
		candleList.get(2).getMacd().setEma3(average);

		for (int i = 3, k = 2; i < candleList.size(); i++, k++) {
			Candle c1 = candleList.get(i);
			Double currentClose = c1.getClose();
			Double prevEma = candleList.get(k).getMacd().getEma3();
			Double EMA = (currentClose * ((double) 2 / (3 + 1))) + prevEma * (1 - ((double) 2 / (3 + 1)));
			c1.getMacd().setEma3(EMA);
			EMA = 0.0;
		}
	}	
	
	public static void calculate9EMA(List<Candle> candleList) {

		List<Candle> first9ElementsList = candleList.stream().limit(9).collect(Collectors.toList());
		double average = first9ElementsList.stream().map(d -> d.getClose()).mapToDouble(Number::doubleValue).average().getAsDouble();
		
		candleList.get(8).getMacd().setEma9(average);

		for (int i = 9, k = 8; i < candleList.size(); i++, k++) {
			Candle c1 = candleList.get(i);
			Double currentClose = c1.getClose();
			Double prevEma = candleList.get(k).getMacd().getEma9();
			Double EMA = (currentClose * ((double) 2 / (9 + 1))) + prevEma * (1 - ((double) 2 / (9 + 1)));
			c1.getMacd().setEma9(EMA);
			EMA = 0.0;
		}
	}	
	
	public static void calculateMACDLine(List<Candle> candleList) {
		
		
		ListIterator<Candle> it = candleList.listIterator(8);
		while (it.hasNext()) {
		   
			Candle d = it.next();
		    d.getMacd().setMacd(d.getMacd().getEma3() - d.getMacd().getEma9());
		}
		
	//	candleList.forEach(d->  d.getMacd().setMacd(d.getMacd().getEma3() - d.getMacd().getEma9()));
	
	
	}	
	
	
	public static void calculate15SignalLineEMA(List<Candle> candleList) {

//		List<Candle> first15ElementsList = candleList.stream().skip(9).limit(15).collect(Collectors.toList());
//		double average = first15ElementsList.stream().map(d -> d.getMacd().getMacd()).mapToDouble(Number::doubleValue).average().getAsDouble();
//		
//		candleList.get(24).getMacd().setEmaSignalLine15(average); 

		candleList.forEach(d-> {
		 	System.out.println(d.getMacd().getMacd()+"<>  : "  );
			 		
		});
		
		
	}	
	public static void calculate15SignalLineEMA1(List<Candle> candleList) {

		List<Candle> first15ElementsList = candleList.stream().skip(8).limit(15).collect(Collectors.toList());
		double average = first15ElementsList.stream().map(d -> d.getMacd().getMacd()).mapToDouble(Number::doubleValue).average().getAsDouble();
		
		candleList.get(22).getMacd().setEmaSignalLine15(average); 

		for (int i = 23, k = 22; i < candleList.size(); i++, k++) {
			Candle c1 = candleList.get(i);
			Double currentClose = c1.getMacd().getMacd();
			Double prevEma = candleList.get(k).getMacd().getEmaSignalLine15();
			Double EMA = (currentClose * ((double) 2 / (15 + 1))) + prevEma * (1 - ((double) 2 / (15 + 1)));
			c1.getMacd().setEmaSignalLine15(EMA);
			EMA = 0.0;
		}
	}	
	
	public static void calculate100EMA(List<Candle> candleList) {

		List<Candle> first100ElementsList = candleList.stream().limit(100).collect(Collectors.toList());
		double average = first100ElementsList.stream().map(d -> d.getClose()).mapToDouble(Number::doubleValue).average()
				.getAsDouble();
		candleList.get(99).setEma100(average);

		for (int i = 100, k = 99; i < candleList.size(); i++, k++) {
			Candle c1 = candleList.get(i);
			Double currentClose = c1.getClose();
			Double prevEma = candleList.get(k).getEma100();
			Double EMA = (currentClose * ((double) 2 / (100 + 1))) + prevEma * (1 - ((double) 2 / (100 + 1)));
			c1.setEma100(EMA);
			EMA = 0.0;
		}
	}	
	 

}
