package com.vidarbha.caller1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import com.vidarbha.caller1.dto.Candle;
import com.vidarbha.caller1.dto.ZonedCandle;
import com.vidarbha.caller1.util.CallerUtil;

public class CandleProvider {

	public List<Candle> getCandleData(String minute, String dateRange) {
		
		
//15minute?user_id=ZQ5037&oi=1&from=2023-09-02&to=2023-10-02
		RestTemplate restTemplate = new RestTemplate();
		String url = "https://kite.zerodha.com/oms/instruments/historical/256265/"+minute+"?user_id=ZQ5037&oi=1&from="+dateRange;

		HttpHeaders httpHeaders = getHedders();

		ResponseEntity<String> stringValue = restTemplate.exchange(url, HttpMethod.GET, new HttpEntity<Object>(httpHeaders), String.class);
		return prepareCandle(stringValue);

	}
 

	public List<ZonedCandle> getZonalCandleData(String minute, String dateRange) {
		 
				RestTemplate restTemplate = new RestTemplate();
				String url = "https://kite.zerodha.com/oms/instruments/historical/SBIN/"+minute+"?user_id=ZQ5037&oi=1&from="+dateRange;

				HttpHeaders httpHeaders = getHedders();

				ResponseEntity<String> stringValue = restTemplate.exchange(url, HttpMethod.GET, new HttpEntity<Object>(httpHeaders), String.class);
				
				
				
				
				return prepareZonalCandle(stringValue);

			}
	private static List<Candle> prepareCandle(ResponseEntity<String> stringValue) throws JsonSyntaxException {
		
		List<Candle> candles = new ArrayList<>();
		
		JsonObject jobj = new Gson().fromJson(stringValue.getBody(), JsonObject.class);
		JsonObject fieldValue = jobj.get("data").getAsJsonObject();
		JsonArray jsonCandleList = fieldValue.get("candles").getAsJsonArray();

		jsonCandleList.forEach(jsonCandleItem -> {

			JsonArray jsonArrayCandle = jsonCandleItem.getAsJsonArray();
			Candle candle = new Candle(CallerUtil.getDateFromFieldValue(jsonArrayCandle.get(0).getAsString()),
					jsonArrayCandle.get(1).getAsDouble(), jsonArrayCandle.get(2).getAsDouble(),
					jsonArrayCandle.get(3).getAsDouble(), jsonArrayCandle.get(4).getAsDouble());

			candles.add(candle);

		});

		Collections.sort(candles, (a, b) -> a.getTime().compareTo(b.getTime()));
		return candles;
	}
	
	
	private static List<ZonedCandle> prepareZonalCandle(ResponseEntity<String> stringValue) throws JsonSyntaxException {
		
		List<ZonedCandle> candles = new ArrayList<>();
		
		JsonObject jobj = new Gson().fromJson(stringValue.getBody(), JsonObject.class);
		JsonObject fieldValue = jobj.get("data").getAsJsonObject();
		JsonArray jsonCandleList = fieldValue.get("candles").getAsJsonArray();

		jsonCandleList.forEach(jsonCandleItem -> {

			JsonArray jsonArrayCandle = jsonCandleItem.getAsJsonArray();
			ZonedCandle candle = new ZonedCandle(CallerUtil.getZonalDateFromFieldValue(jsonArrayCandle.get(0).getAsString()),
					jsonArrayCandle.get(1).getAsDouble(), jsonArrayCandle.get(2).getAsDouble(),
					jsonArrayCandle.get(3).getAsDouble(), jsonArrayCandle.get(4).getAsDouble());

			candles.add(candle);

		});

		Collections.sort(candles, (a, b) -> a.getTime().compareTo(b.getTime()));
		return candles;
	}
	
	

	private static HttpHeaders getHedders() {
		HttpHeaders httpHeaders = new HttpHeaders() {
			{
				set("Authorization",
	 "enctoken QViRj0EhVf5YRi5ikTVjzUPD2ceix+uU36QH7FQpvKj6rpSsHNN8C8ykgDCJpoE5F5bXrS7UZCZ1PzDB9jjkEwl/LeaVzvISTpQglbeRy1qLckpKg9LMBw==");
			}
		};
		return httpHeaders;
	}

}
