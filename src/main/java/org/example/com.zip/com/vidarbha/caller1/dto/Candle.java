package com.vidarbha.caller1.dto;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;

public class Candle {

	@Override
	public String toString() {
		return "Candle [time=" + time + ", open=" + open + ", high=" + high + ", low=" + low
				+ ", close=" + close + ", ema200=" + ema200 + ", ema100=" + ema100 + ", ema50="
				+ ema50 + ", ema20=" + ema20 + ", sma20=" + sma20 + ", band=" + band + ", macd="
				+ macd + "]"; 
	}


	LocalDateTime time;
	Double open;
	Double high;
	Double low;
	Double close; 
	
	Double ema200; 
	Double ema100; 
	Double ema50; 
	Double ema20; 
	Double sma20;  
	
	Band band;
	MACD macd = new MACD();
	
	
	public Band getBand() {
		return band;
	}


	public void setBand(Band band) {
		this.band = band;
	}


	public Double getSma20() {
		return sma20;
	}


	public void setSma20(Double sma20) {
		this.sma20 = sma20;
	}




	public Candle(LocalDateTime time, Double open, Double high, Double low, Double close) {
		super();
		this.time = time;
		this.open = open;
		this.high = high;
		this.low = low;
		this.close = close; 
	}
	
	
	public LocalDateTime getTime() {
		return time;
	}
	public void setTime(LocalDateTime time) {
		this.time = time;
	}
	public Double getOpen() {
		return open;
	}
	public void setOpen(Double open) {
		this.open = open;
	}
	public Double getHigh() {
		return high;
	}
	public void setHigh(Double high) {
		this.high = high;
	}
	public Double getLow() {
		return low;
	}
	public void setLow(Double low) {
		this.low = low;
	}
	public Double getClose() {
		return close;
	}
	public void setClose(Double close) {
		this.close = close;
	}
	 
	
	public MACD getMacd() {
		return macd;
	}


	public void setMacd(MACD macd) {
		this.macd = macd;
	}

	
	public Double getEma200() {
		return ema200;
	}


	public void setEma200(Double ema200) {
		this.ema200 = ema200;
	}


	public Double getEma100() {
		return ema100;
	}


	public void setEma100(Double ema100) {
		this.ema100 = ema100;
	}


	public Double getEma50() {
		return ema50;
	}


	public void setEma50(Double ema50) {
		this.ema50 = ema50;
	}


	public Double getEma20() {
		return ema20;
	}


	public void setEma20(Double ema20) {
		this.ema20 = ema20;
	}

	public boolean isNegativeCandle() {
		return this.open > this.close;
	}

	public boolean isStrongCloseCandle() {
		if(this.isNegativeCandle()) {
		return this.close == this.low;	
		}
		if(!this.isNegativeCandle()) {
			return this.close == this.high;	
		}
		return false;
	}

	
	
}
