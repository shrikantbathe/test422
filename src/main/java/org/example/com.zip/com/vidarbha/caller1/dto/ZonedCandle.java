package com.vidarbha.caller1.dto;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZonedDateTime;

public class ZonedCandle {

	ZonedDateTime time;
	Double open;
	Double high;
	Double low;
	Double close; 
	
	Double ema200; 
	Double ema100; 
	Double ema50; 
	Double ema20;  
	

	public ZonedCandle(ZonedDateTime time, Double open, Double high, Double low, Double close) {
		super();
		this.time = time;
		this.open = open;
		this.high = high;
		this.low = low;
		this.close = close; 
	}
	
	
	public ZonedDateTime getTime() {
		return time;
	}
	public void setTime(ZonedDateTime time) {
		this.time = time;
	}
	public Double getOpen() {
		return open;
	}
	public void setOpen(Double open) {
		this.open = open;
	}
	public Double getHigh() {
		return high;
	}
	public void setHigh(Double high) {
		this.high = high;
	}
	public Double getLow() {
		return low;
	}
	public void setLow(Double low) {
		this.low = low;
	}
	public Double getClose() {
		return close;
	}
	public void setClose(Double close) {
		this.close = close;
	}
	
	public Double getEma200() {
		return ema200;
	}


	public void setEma200(Double ema200) {
		this.ema200 = ema200;
	}


	public Double getEma100() {
		return ema100;
	}


	public void setEma100(Double ema100) {
		this.ema100 = ema100;
	}


	public Double getEma50() {
		return ema50;
	}


	public void setEma50(Double ema50) {
		this.ema50 = ema50;
	}


	public Double getEma20() {
		return ema20;
	}


	public void setEma20(Double ema20) {
		this.ema20 = ema20;
	}

	
	
}
