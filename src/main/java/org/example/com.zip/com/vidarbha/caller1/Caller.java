package com.vidarbha.caller1;

import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

import com.vidarbha.caller1.dto.Candle;

public class Caller {

	public static void main(String[] args) {

//	List<Candle> candleList = CandleProvider.getCandleData("5minute", "2023-08-29&to=2023-10-29") ;
		List<Candle> originalCandle = new CandleProvider().getCandleData("day", "2025-06-09&to=2026-06-26");

		
		set20Dma(originalCandle );
		
		originalCandle.forEach(d -> {
			System.out.println("-->" + d.getTime() + " <> " + d.getClose()+ " <dma> " + d.getEma50());
		}
		);
		
	}
	
	public static void set20Dma(List<Candle> dailyCandle){
		
		int k = 0;
		for (int i=19; i < dailyCandle.size(); i++) {			
			dailyCandle.get(i).setEma20(getDma(dailyCandle.subList(k,dailyCandle.size()), 20));	
			k++;
		}

		
	}
	
	
	
	
	public static double getDma(List<Candle> dailyCandle, int count){
		double  list = dailyCandle.stream().limit(count).map(d->d.getClose()).collect(Collectors.averagingDouble(d->d));
		return list;
	}
	
	
	
	//	List<Candle>   asdasdasd= new Caller().prepareEma200(candleList15);

//	System.out.println("-->"+candleList.size());
		// System.out.println("-->"+candleList15.getTime());

//		asdasdasd.stream().forEach(d -> {
//			System.out.println("-->" + d.getTime() + " <> " + d.getClose() + " <> " + d.getEma200());
//		});

	//}

	
	
	
	
	
	
	
	
	
	
	
	
	public Double ema200Yest;
	Double  dma = null;
	
	public List<Candle>  prepareEma200(List<Candle> candleList) {

		if (candleList.size() < 1) return null;

		dma = candleList.stream().limit(200).mapToDouble(d -> d.getClose()).average().getAsDouble();
		List<Candle> candleList2 = candleList.stream().skip(200).collect(Collectors.toList());

		candleList2.forEach(d -> {
			double ema200 = (d.getClose() * ((2 / (1 + 200)))) + (dma * (1 - ((2 / (1 + 200)))));
			d.setEma200(ema200);
			dma = ema200;
		}
		);
		
		return candleList2;

	}

}
