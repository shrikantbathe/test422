package com.vidarbha.caller1.dto;

public class MACD {

//	Double ema12; 
//	Double ema26; 
//	Double emaSignalLine9;  	  

	public MACD(Double ema3, Double ema9,Double macd, Double emaSignalLine15) {
		super();
		this.ema3 = ema3;
		this.ema9 = ema9;
		this.macd = macd;
		this.emaSignalLine15 = emaSignalLine15;
	}
	
	@Override
	public String toString() {
		return "MACD [macd=" + macd + ", ema3=" + ema3 + ", ema9=" + ema9
				+ ", emaSignalLine15=" + emaSignalLine15 + "]";
	}
	
	public MACD() { }

	Double macd;
	Double ema3;
	Double ema9;
	Double emaSignalLine15;

	public Double getMacd() {
		return macd;
	}

	public void setMacd(Double macd) {
		this.macd = macd;
	}
	
	public Double getEma3() {
		return ema3;
	}

	public void setEma3(Double ema3) {
		this.ema3 = ema3;
	}

	public Double getEma9() {
		return ema9;
	}
	
	public void setEma9(Double ema9) {
		this.ema9 = ema9;
	}

	public Double getEmaSignalLine15() {
		return emaSignalLine15;
	}

	public void setEmaSignalLine15(Double emaSignalLine15) {
		this.emaSignalLine15 = emaSignalLine15;
	}

}
