package com.vidarbha.caller1.util;
 

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ClockPopup {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Current Time");
        JLabel timeLabel = new JLabel();
        timeLabel.setFont(new Font("Arial", Font.BOLD, 32));
        timeLabel.setHorizontalAlignment(SwingConstants.CENTER);
        frame.add(timeLabel);
        frame.setSize(300, 150);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.getContentPane().setBackground(Color.PINK);
        frame.setAlwaysOnTop(true);

        Timer timer = new Timer(1000, new ActionListener() {
            private boolean isPink = true;
            private long lastColorChange = System.currentTimeMillis();
            @Override
            public void actionPerformed(ActionEvent e) {
                String time = new SimpleDateFormat("HH:mm:ss.SSS").format(new Date());
                timeLabel.setText(time);
                long now = System.currentTimeMillis();
                if (now - lastColorChange >= 30000) { // 30 seconds
                    isPink = !isPink;
                    frame.getContentPane().setBackground(isPink ? Color.PINK : Color.GREEN);
                    lastColorChange = now;
                    Toolkit.getDefaultToolkit().beep(); // Play a beep sound
                }
            }
        });
        timer.start();

        frame.setVisible(true);
    }
}

