package com.vidarbha.caller1.util;


import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class CallerUtil { 
	
	
	public static LocalDateTime getDateFromFieldValue(String fieldValue) {

		if (fieldValue == null) return null;

//		String dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
		String dateFormat = "yyyy-MM-dd'T'HH:mm:ssX";
		try {
			return LocalDateTime.parse(fieldValue, DateTimeFormatter.ofPattern(dateFormat));
		} catch (DateTimeParseException e) {
			return null;
		}
	}	
	
	
	public static ZonedDateTime getZonalDateFromFieldValue(String fieldValue) {

		if (fieldValue == null) return null;

		try {
			return ZonedDateTime.parse(createDateString(fieldValue));
		} catch (DateTimeParseException e) {
			return null;
		}
	}	
	
	
	public static String createDateString(String str) {
		return str.replace("00+0530", "00.000000000+05:30[Asia/Calcutta]");
	}
	
	
}
	