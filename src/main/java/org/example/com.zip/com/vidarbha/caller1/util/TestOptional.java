package com.vidarbha.caller1.util;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public class TestOptional {

	public static Map<String, BBB> map = new HashMap<>();

	public static void main(String[] args) {
		add();
		
		for(Map.Entry<String,BBB> en: map.entrySet()) {
			String name = Optional.ofNullable(en.getValue()).map(BBB::getAaa).map(AAA::getName).orElse("XXX");
			System.out.println(name);
		}
	}

	public static void add() {
		
		BBB bbb = new BBB();
		AAA aaa = new AAA();
		aaa.setName("PUNE");
		bbb.setAaa(aaa);
		
		BBB bbb1 = new BBB();
		
		BBB bbb11 = new BBB();
		AAA aaa11 = new AAA();
		bbb11.setAaa(aaa11);
		
		map.put("shri", null);
		map.put("swati", bbb);
		map.put("swati1", bbb1);
		map.put("swati23", bbb11);
	}

}

class BBB {

	AAA aaa;

	public AAA getAaa() {
		return aaa;
	}

	public void setAaa(AAA aaa) {
		this.aaa = aaa;
	}  
	 
}


class AAA {

	String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}