package com.vidarbha.caller1.algo;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import com.vidarbha.caller1.dto.Band;
import com.vidarbha.caller1.dto.Candle;

public class IndicatorUtil {

	public static void calculate20EMA(List<Candle> candleList) {
		 
		List<Candle> first20ElementsList = candleList.stream().limit(20).collect(Collectors.toList());
		double average = first20ElementsList.stream().map(d -> d.getClose()).mapToDouble(Number::doubleValue).average()
				.getAsDouble();
		candleList.get(19).setEma20(average);

		for (int i = 20, k = 19; i < candleList.size(); i++, k++) {
			Candle c1 = candleList.get(i);
			Double currentClose = c1.getClose();
			Double prevEma = candleList.get(k).getEma20();
			Double EMA = (currentClose * ((double) 2 / (20 + 1))) + prevEma * (1 - ((double) 2 / (20 + 1)));
			c1.setEma20(EMA);
			EMA = 0.0;
		}
	}		

	public static void calculate20SMA(List<Candle> candleList) {
	
		if (candleList == null || candleList.size() < 20) {
			return;
		}
		
		for (int i = 19; i < candleList.size(); i++) {
			Double sum = 0.0;
			for (int j = i - 19; j <= i; j++) {
				sum += candleList.get(j).getClose();
			}
			Double sma = sum / 20.0;
			Candle can = candleList.get(i-19);
			can.setSma20(sma); // Assumes Candle has setSma20(Double) method
			setBand(candleList,can,sma);
		}
	  
	}
	

	public static void setBand(List<Candle> candleList,Candle candle, Double sma) {
		Double variance = 0.0;
		for (Candle c : candleList) {
			variance += Math.pow(c.getClose() - sma, 2);
		}
		variance /= 20.0;
		Double stddev = Math.sqrt(variance);
		Double upperBand = sma + (2 * stddev);
		Double lowerBand = sma - (2 * stddev); 
		candle.setBand(new Band(sma,upperBand,lowerBand));
	}
	
	
	public static void calculate20SMAaa(List<Candle> candleList) {
		Collections.reverse(candleList);
		for (Candle candle : candleList) {
		    int idx = candleList.indexOf(candle);
		    if (idx >= 19) {
		        List<Candle> prev20 = candleList.subList(idx - 19, idx + 1);
		       // System.out.println("Size of prev20: " + prev20.size());
		        calculate20SMA(prev20); 
		    }
		}
		Collections.reverse(candleList);
	}
	
	
	public static void calculate50EMA(List<Candle> candleList) {

		List<Candle> first50ElementsList = candleList.stream().limit(50).collect(Collectors.toList());
		double average = first50ElementsList.stream().map(d -> d.getClose()).mapToDouble(Number::doubleValue).average()
				.getAsDouble();
		candleList.get(49).setEma50(average);

		for (int i = 50, k = 49; i < candleList.size(); i++, k++) {
			Candle c1 = candleList.get(i);
			Double currentClose = c1.getClose();
			Double prevEma = candleList.get(k).getEma50();
			Double EMA = (currentClose * ((double) 2 / (50 + 1))) + prevEma * (1 - ((double) 2 / (50 + 1)));
			c1.setEma50(EMA);
			EMA = 0.0;
		}
	}	
	
	public static void calculate100EMA(List<Candle> candleList) {

		List<Candle> first100ElementsList = candleList.stream().limit(100).collect(Collectors.toList());
		double average = first100ElementsList.stream().map(d -> d.getClose()).mapToDouble(Number::doubleValue).average()
				.getAsDouble();
		candleList.get(99).setEma100(average);

		for (int i = 100, k = 99; i < candleList.size(); i++, k++) {
			Candle c1 = candleList.get(i);
			Double currentClose = c1.getClose();
			Double prevEma = candleList.get(k).getEma100();
			Double EMA = (currentClose * ((double) 2 / (100 + 1))) + prevEma * (1 - ((double) 2 / (100 + 1)));
			c1.setEma100(EMA);
			EMA = 0.0;
		}
	}	
	
	public static void calculate200EMA(List<Candle> candleList) {

		List<Candle> first200ElementsList = candleList.stream().limit(200).collect(Collectors.toList());
		double average = first200ElementsList.stream().map(d -> d.getClose()).mapToDouble(Number::doubleValue).average().getAsDouble();
		candleList.get(199).setEma200(average);

		for (int i = 200, k = 199; i < candleList.size(); i++, k++) {
			Candle c1 = candleList.get(i);
			Double currentClose = c1.getClose();
			Double prevEma = candleList.get(k).getEma200();
			Double EMA = (currentClose * ((double) 2 / (200 + 1))) + prevEma * (1 - ((double) 2 / (200 + 1)));
			c1.setEma200(EMA);
			EMA = 0.0;
		}
	}	
	
 
	public static void setRsiBearFlag(List<Candle> candleList) {
		Collections.reverse(candleList);
		 
	}	
	
 
	
	
	public static double getDmaaaa(List<Candle> dailyCandle, int count) {
		double list = dailyCandle.stream().limit(count).map(d -> d.getClose())
				.collect(Collectors.averagingDouble(d -> d));
		return list;
	}

}
