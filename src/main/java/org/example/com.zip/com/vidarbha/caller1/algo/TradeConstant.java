package com.vidarbha.caller1.algo;

import java.util.List;

import com.vidarbha.caller1.dto.Candle;

public class TradeConstant	 { 
	
	
	public static final double NIFTY_MIN_MACD_DIFF = 20;
	
	
	
	
}
