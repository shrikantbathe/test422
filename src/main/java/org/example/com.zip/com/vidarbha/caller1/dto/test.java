package com.vidarbha.caller1.dto;

public class test {

	public static void main(String[] args) {
	 

		
		
		String sd = "qweqweqweqw";
		
		boolean ssd = sd.matches(".*\\d.*");
		
		
		System.out.println(ssd);
	}

}
