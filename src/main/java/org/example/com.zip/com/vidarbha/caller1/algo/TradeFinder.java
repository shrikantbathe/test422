package com.vidarbha.caller1.algo;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import com.vidarbha.caller1.dto.Candle;
import com.vidarbha.caller1.dto.MACD;

public class TradeFinder {
	
	 public static void main(String[] args) {

		 List<Candle> list = CandleList.getCandleSeries("15minute", "2026-01-01&to=2026-07-10");
		 List<Candle> list5Min = CandleList.getCandleSeries("5minute", "2026-04-02&to=2026-07-10");
		 List<Candle> list5Min2 = CandleList.getCandleSeries("5minute", "2026-01-01&to=2026-04-01");
		 
		 list5Min.addAll(list5Min2);
		 
		 
		 
		 for (int i= 0; i< list.size(); i++ ) {
			 
			 Candle ca = list.get(i);
			 
			 if(isNegative15MinCandle(ca)) {
				 
				 
				 LocalDateTime localTime1 	= ca.getTime();
				 LocalDateTime localTime2 	= localTime1.plusMinutes(5);
				 LocalDateTime localTime3 	= localTime1.plusMinutes(10);
			//	 System.out.println("localTime1:- " +localTime1 + "localTime2:- " +localTime2 + "localTime3:- " +localTime3);

				 Optional<Candle> last = list5Min.stream().filter(x-> x.getTime().equals(localTime3)).findFirst();
				 Optional<Candle> secondLast = list5Min.stream().filter(x-> x.getTime().equals(localTime2)).findFirst();
				 
				 Candle c1 = last.get();
				 Candle c2 = secondLast.get();
				 
				 
				 MACD macd =  c1.getMacd();
				 Double blackc1  = macd.getMacd();
				 Double redc1  = macd.getEmaSignalLine15();
				 
				 if (blackc1 == null || redc1 ==null) continue;
				 
				 if ((blackc1 < 0 && redc1<0) && (blackc1 < redc1))  {
					 
					 MACD macd2 =  c2.getMacd();
					 Double blackc2  = macd2.getMacd();
					 Double redc2  = macd2.getEmaSignalLine15();
					 
					 if (blackc2 == null || redc2 ==null) continue;
					 if ((blackc2 < 0 && redc2<0) && (blackc2 <  redc2)) {
						 System.out.println("Negative ::: " + c1.toString());
						 
					 }
				 }
				 
	    	  // System.out.println( ca.toString());
	       } else if (isPositive15MinCandle(ca)) {
	    	   
	    	   
				 LocalDateTime localTime1 	= ca.getTime();
				 LocalDateTime localTime2 	= localTime1.plusMinutes(5);
				 LocalDateTime localTime3 	= localTime1.plusMinutes(10);
			//	 System.out.println("localTime1:- " +localTime1 + "localTime2:- " +localTime2 + "localTime3:- " +localTime3);

				 Optional<Candle> last = list5Min.stream().filter(x-> x.getTime().equals(localTime3)).findFirst();
				 Optional<Candle> secondLast = list5Min.stream().filter(x-> x.getTime().equals(localTime2)).findFirst();
				 
				 Candle c1 = last.get();
				 Candle c2 = secondLast.get();
				 
				 
				 MACD macd =  c1.getMacd();
				 Double blackc1  = macd.getMacd();
				 Double redc1  = macd.getEmaSignalLine15();
				 
				 if (blackc1 == null || redc1 ==null) continue;
				 
				 if ((blackc1 > 0 && redc1 > 0) && (blackc1 > redc1))  {
					 
					 MACD macd2 =  c2.getMacd();
					 Double blackc2  = macd2.getMacd();
					 Double redc2  = macd2.getEmaSignalLine15();
					 
					 if (blackc2 == null || redc2 ==null) continue;
					 if ((blackc2 > 0 && redc2 > 0) && (blackc2 > redc2)) {
						 System.out.println("Positive ::: " + c1.toString());
						
					 }
				 }
				 
				 
				  
			       
				 
	    	   
	       }
			 
				// Candle ca = list.get(i);
			  if (!ca.getTime().toLocalDate().equals(list.get(i+1).getTime().toLocalDate())) {
				  System.out.println("");
			  }
			 
			  
			  
		
		 }
	    }
	 
	 private static Candle getSellSignalFor5Min(List<Candle> Candle1List, int i) {
		 Candle ca = Candle1List.get(i);
		 
		 if (ca.getOpen() > ca.getClose()) {
			 if ((ca.getOpen() - ca.getClose()) > 20) {
				// System.out.println("ccccc:"+ ca.toString());
				 MACD macd =  ca.getMacd();
				 Double black  = macd.getMacd();
				 Double red  = macd.getEmaSignalLine15();
				 if (red == null || black ==null) return null;
				 
				 if ((black < 0 && red<0) && (black < red)) {
//					 Candle ca2 = Candle1List.get(i+1);
//					 MACD macd2 =  ca2.getMacd();
//					 double black2  = macd2.getMacd();
//					 double red2  = macd2.getEmaSignalLine15();
//					 if ((black2 < 0 && red2<0) && (black2 < red2)) {
//						 if ((black2 < black && red2< red)) {
//							 return ca;
//						 }
//					 }
					 return ca;
				 }
			 }
		 }
		 return null; 
	     }
	 
	 
	 private static boolean isNegative15MinCandle(Candle ca) {
		 
		 if (ca.getOpen() > ca.getClose()) {
			 if ((ca.getOpen() - ca.getClose()) > 25) {
				// System.out.println("ccccc:"+ ca.toString());
				 MACD macd =  ca.getMacd();
				 Double black  = macd.getMacd();
				 Double red  = macd.getEmaSignalLine15();
				 if (red == null || black ==null) return false;
				 if ((black < 1 ) && (black < red)) {
					 return true;
				 }
			 }
		 }
		 return false; 
	     }
	 
	 
	 private static boolean isPositive15MinCandle(Candle ca) {
		 
		 if (ca.getOpen() < ca.getClose()) {
			 if ((ca.getClose() - ca.getOpen()) > 25) {
				 MACD macd =  ca.getMacd();
				 Double black  = macd.getMacd();
				 Double red  = macd.getEmaSignalLine15();
				 if (red == null || black ==null) return false;
				 if ((black > -1 ) && (black > red)) {
					 return true;
				 }
			 }
		 }
		 return false; 
	     }
	 
	 
	 
}
