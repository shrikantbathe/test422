package com.vidarbha.caller1.algo;

import java.util.List;

import com.vidarbha.caller1.dto.Candle;

public class Filter {
 

		 public static void main1(List<Candle> list ) {


		        for (int i=0;i< list.size();i++) {
		        		
		        	if (i>1) {
		        		Candle  candle = list.get(i);
		        		Candle  candle1 = list.get(i-1);
		        		Candle  candle2 = list.get(i-2);
		        		if (candle.getMacd().getEmaSignalLine15() != null && candle1.getMacd().getEmaSignalLine15() != null && candle2.getMacd().getEmaSignalLine15() != null) {
		        			
		        		
		        			Double d = (candle.getMacd().getMacd() - 
		        				candle.getMacd().getEmaSignalLine15());
		        			Double d1 = (candle1.getMacd().getMacd() - candle1.getMacd().getEmaSignalLine15());
		        			Double d2 = (candle2.getMacd().getMacd() - candle2.getMacd().getEmaSignalLine15());
		        		 	
		        			Double signalA = candle.getMacd().getMacd();
		        			Double signalB = candle1.getMacd().getMacd();
		        			Double signalC = candle2.getMacd().getMacd();
		        			 
		        			Double emaA =candle.getMacd().getEmaSignalLine15();
		        			Double emaA1 =candle1.getMacd().getEmaSignalLine15();
		        			Double emaA2 =candle2.getMacd().getEmaSignalLine15();
		        			
		        			if ( (signalA <=signalB && signalB<= signalC) && (signalA< emaA && signalB< emaA1 && signalC< emaA2)) {
		        				
		        				
		        				if  (((signalA -emaA ) <0 && (signalA -emaA )> -12) && 
		        						((signalB -emaA ) <0 && (signalB -emaA1 )> -12) && 
		        						((signalC -emaA ) <0 && (signalC -emaA2)> -12) )
		            						
		        						
		        						{
		        			 //	if ((d>-5 &&d1>-5 &&d2>-5 )&&  (d< 0 &&d1< 0 &&d2< 0 ) && candle2.getMacd().getEmaSignalLine15()>-5) {
		        			 System.out.println(candle.getClose() + "<xx>  : " + candle.getTime() + "<> RED : " + candle.getMacd().getEmaSignalLine15() + "<> "
		        			 		+ "BLACK : " + 
		        					 candle.getMacd().getMacd() + "<>  : " +
		                 		(candle.getMacd().getMacd() - candle.getMacd().getEmaSignalLine15()));
		        			 	//}
		        			}
		        			}
		        		}
		        	}
		        	
		        }
		       
		    }

 
}
