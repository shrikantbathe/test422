package com.vidarbha.caller1.algo;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

import org.ta4j.core.BarSeries;
import org.ta4j.core.BaseBarSeriesBuilder;

import com.vidarbha.caller1.CandleProvider;
import com.vidarbha.caller1.dto.Candle;
import com.vidarbha.caller1.dto.ZonedCandle;

public class DataFetcher {

	 
	
	public  List<ZonedCandle> getFifteenMinTimeSeries(){
	
		 List<ZonedCandle> originalCandle = new CandleProvider().getZonalCandleData("15minute",  "2023-12-02&to=2024-01-01");
		// ZonedDateTime.parse("2023-09-04T09:15:00+0530");
		// 2023-09-04T09:15:00+0530
		// System.out.println("-->" + ZonedDateTime.now());
  	    // System.out.println("-->" + ZonedDateTime.parse("2024-01-01T17:59:00.000000000+05:30[Asia/Calcutta]"));
		// 2023-09-04T09:15:00+0530
		// '2011-12-03T10:15:30+01:00[Europe/Paris]'
		// 2024-01-01T17:59:00.000000000+05:30[Asia/Calcutta]
			return originalCandle;	
	}
	
	public  List<Candle> getNormalCandleFifteenMinTimeSeries(String minute, String dateRange){
		 List<Candle> originalCandle = new CandleProvider().getCandleData(minute, dateRange);
		 //List<Candle> originalCandle = new CandleProvider().getCandleData("15minute",  "2024-07-20&to=2024-08-23");
			return originalCandle;	
	}
	
	
	

	
}
