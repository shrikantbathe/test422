package com.vidarbha.caller1.dto;

public class Band { 
	
	
	public final Double middle;
    public final Double upper;
    public final Double lower;

    public Band(Double middle, Double upper, Double lower) {
        this.middle = middle;
        this.upper = upper;
        this.lower = lower;
    }

	public Double getMiddle() {
		return middle;
	}

	public Double getUpper() {
		return upper;
	}

	public Double getLower() {
		return lower;
	}

	 
    
}
