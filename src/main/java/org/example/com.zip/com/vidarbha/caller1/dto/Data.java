package com.vidarbha.caller1.dto;

import java.util.List;

public class Data {

	List<Candle> candles;

	public List<Candle> getCandles() {
		return candles;
	}

	public void setCandles(List<Candle> candles) {
		this.candles = candles;
	}
	
}
